// Load test: 12 clients, host fires 300 play/pause/seek ops; measures server->client propagation (same machine clock).
const WebSocket=require('ws'),URL='ws://localhost:'+(process.env.PORT||3000),N=12,OPS=300;
const open=()=>new Promise(r=>{const w=new WebSocket(URL);w.on('open',()=>r(w))});
const msgs=(w,f)=>w.on('message',d=>f(JSON.parse(d)));
(async()=>{
 const host=await open();let code;const lat=[];
 msgs(host,m=>{if(m.t==='room')code=m.code});host.send(JSON.stringify({t:'join',create:true,id:'h',name:'h'}));
 await new Promise(r=>setTimeout(r,200));
 for(let i=1;i<N;i++){const w=await open();msgs(w,m=>{if(m.t==='state'&&m.c)lat.push(Date.now()-m.c)});w.send(JSON.stringify({t:'join',room:code,id:'u'+i,name:'u'+i}))}
 await new Promise(r=>setTimeout(r,300));
 const ops=['play','pause','seek'];
 for(let i=0;i<OPS;i++){host.send(JSON.stringify({t:'ctl',op:ops[i%3],pos:i,c:Date.now()}));await new Promise(r=>setTimeout(r,10))}
 await new Promise(r=>setTimeout(r,500));
 const late=await open();let snap;msgs(late,m=>{if(m.t==='room')snap=m});late.send(JSON.stringify({t:'join',room:code,id:'late',name:'late'}));
 await new Promise(r=>setTimeout(r,300));
 lat.sort((a,b)=>a-b);const p=q=>lat[Math.floor(q*lat.length)];
 console.log({samples:lat.length,expected:OPS*(N-1),p50:p(.5),p95:p(.95),max:lat.at(-1),lateJoinGotState:!!snap&&snap.video.v===OPS});
 console.log(p(.95)<=250?'PASS p95<=250ms':'FAIL');process.exit();
})();
